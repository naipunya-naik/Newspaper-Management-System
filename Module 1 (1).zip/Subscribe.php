<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid;
$sql="SELECT s.pid,r.papername FROM subscribers s,requirements r where r.pid=s.pid and s.email='$uid'";
$res=mysqli_query($conn,$sql);
?>
<html>

    <body>
	
	<!DOCTYPE html>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<form action="" method="POST" onsubmit="return submitform(this);"> 
<table>
  <tr>
    <th>pid</th>
    <th>papername</th>
	<th>Unsubscribe</th>
  </tr>
  <?php   
  $count=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
		  <tr>
			<td><?php echo $row['pid'] ?></td>
			<td><?php echo $row['papername'] ?></td>
			<td> 
				<div>
						<button type="submit" class="signupbtn" name='submit<?php echo $row['pid']; ?>' value="abc" >Unsubscribe</button>
				</div>
			 </td>
				
		  </tr>
			
  <?php
  $count++;
  }
  ?>
</table>
</form>
</body>
</html>
<script>
	function submitform(){
		return confirm('Do You really want to unsubscribe ?');
	}
</script>

<?php
if(isset($_POST['submit1']))
{
	$sql2="DELETE from subscribers where pid=1 and email='$uid'";
	$res2=mysqli_query($conn,$sql2);
	header("Refresh:0; url=custom-require.php?uid=$uid");
}
if(isset($_POST['submit2']))
{
	$sql2="DELETE from subscribers where pid=2 and email='$uid'";
	$res2=mysqli_query($conn,$sql2);
	header("Refresh:0; url=custom-require.php?uid=$uid");
}
if(isset($_POST['submit3']))
{
	$sql2="DELETE from subscribers where pid=3 and email='$uid'";
	$res2=mysqli_query($conn,$sql2);
	header("Refresh:0; url=custom-require.php?uid=$uid");
}
if(isset($_POST['submit4']))
{
	$sql2="DELETE from subscribers where pid=4 and email='$uid'";
	$res2=mysqli_query($conn,$sql2);
	header("Refresh:0; url=custom-require.php?uid=$uid");
}
if(isset($_POST['submit5']))
{
	$sql2="DELETE from subscribers where pid=5 and email='$uid'";
	$res2=mysqli_query($conn,$sql2);
	header("Refresh:0; url=custom-require.php?uid=$uid");
}
if(isset($_POST['submit6']))
{
	$sql2="DELETE from subscribers where pid=6 and email='$uid'";
	$res2=mysqli_query($conn,$sql2);
	header("Refresh:0; url=custom-require.php?uid=$uid");
}

?>
