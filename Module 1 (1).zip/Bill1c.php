<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid."<br>";
$pid = $_GET['pid'];
echo "pid".$pid;
$sql= "SELECT name,phonenumber,address from customer_details WHERE email='$uid'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($res);
$sql1= "INSERT into subscribers(email,pid) values( '$uid', '$pid')";
mysqli_query($conn,$sql1);
$sql2= "INSERT into subs(email,pid) values( '$uid', '$pid')";
mysqli_query($conn,$sql2);

$cur_date=date("Y-m-d");
echo $cur_date."<br>";
$date_m1=strtotime("+180 days",strtotime($cur_date)); 
$dateX=date("Y-m-d",$date_m1);
echo $dateX;

?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    
    <style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: left;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
    </style>
</head>
<link rel="stylesheet" href="signupstyle-bill.css"></link>

<body>
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                                <h1> BILL RECEIPT </h1>
                            </td>
							
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                            <td>
                                Sparksuite, Inc.<br>
                                335001 Sunny Road<br>
                                Sunnyville,Mumbai<br>
								9001178911
                            </td>
							<td>
                                Created:<?php
										echo $cur_date;
										?><br>
                                Due:<?php
									echo $dateX;
									?>
                         
							</td>
                            
                        </tr>
                    </table>
                </td>
            </tr>

			<tr class="heading">
                <td>
                    Generated To:
                </td>
				<td>
					contact no
				</td>
				<td>
					address
				</td>
            </tr>
			<tr class="item last">
                <td>
					<?php
					if(!empty($row))
					echo $row['name'];
					?>
                </td>
				<td>
					<?php
					if(!empty($row))
					echo $row['phonenumber'];
					?>
                </td>
				<td>
					<?php
					if(!empty($row))
					echo $row['address'];
					?>
                </td>
            
            
            <tr class="heading">
                <td>
                    Item
                </td>
                
                <td>
                    Price
                </td>
				<td>
                    <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                </td>
                
            </tr>
            
            
            <tr class="item last">
                <td>
                    The Hindustan Times (6 month)
                </td>
                
                <td>
                    Rs.720.00
                </td>
            </tr>
            
            
            <tr class="total">
                <td></td>
                
                <td>
                   Total: Rs.720.00
                </td>
            </tr>
        </table>
    </div>

	<div class="clearfix">
     
      <button type="submit" class="signupbtn" name="submit" value="abc" onclick="window.location.href='custom-require.php?uid=<?php echo $uid ?>'">Continue</button>
    </div>
	<div class="clearfix">
     
      <button type="submit" class="signupbtn" name="submit" value="abc" onclick="window.location.href='new-login.php'"> Done </a></button>
    </div>

	<a href="javascript:window.print()">Click to print</a>

</body>
</html>
