<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid;
$sql="SELECT * FROM requirements";
$res=mysqli_query($conn,$sql);
?>
<html>
<head>
		<link rel="stylesheet" href="style1.css"></link>
</head>
<body>
	<div class="topnav">
        <a href="newpass.php?uid=<?php echo $uid?>">Change password</a>
		<a href="new-login.php">Logout</a>
	</div>
	
	<!DOCTYPE html>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<img src="images/images.jfif">
<table>
  <tr>
    <th>Sno</th>
    <th>Newspaper Name</th>
	<th>Cost/Day</th>
	<th>Subscribe here</th>
  </tr>
  <?php   
  $count=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
		  <tr>
			<td><?php echo $row['pid'] ?></td>
			<td><?php echo $row['papername'] ?></td>
			<td><?php echo $row['costperday'] ?></td>
			<td> 
				<div>
						<button type="submit" class="signupbtn" name='submit<?php echo $count; ?>'  id='submit<?php echo $count; ?>' value="abc" onclick="window.location.href='paper-<?php echo $count?>.php?uid=<?php echo $uid?>'">Subscribe</button>
				</div>
			 </td>
				
		  </tr>
			
  <?php
  $count++;
  }
  ?>
</table>
<div class="clearfix" align="center">
     <br>
	 <br>
	 <br>
      <button type="submit" class="" name="submit" value="abc" onclick="window.location.href='Subscribe.php?uid=<?php echo $uid?>'">Unsubscribe</button>
    </div>
</body>
</html>
