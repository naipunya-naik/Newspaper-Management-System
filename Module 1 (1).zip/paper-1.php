<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid;

?>

<html>	
<body>
<h1 align="center">Hindustan Times</h1>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style2.css"></link>
<style>
.button {
  border: none;
  color: white;
  padding: 40px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 40px 60px;
  cursor: pointer;
}

.button1 {background-color: #f44336;} /* Red */
.button2 {background-color: #e7e7e7; color: black;} /* Gray */
.button3 {background-color: #555555;} /* Black */

.button1 {border-radius: 12px;}
.button2 {border-radius: 12px;}
.button3 {border-radius: 12px;}
</style>
</head>
<body>
<img src="images/images.jfif">
<center>
<button class="button button1">1 month <br> (Rs.120) <a href="Bill1a.php?uid=<?php echo $uid ?>&pid=1"><br> Subscribe </a> </button>
<button class="button button2">3 month <br> (Rs.360) <a href="Bill1b.php?uid=<?php echo $uid ?>&pid=1"><br> Subscribe </a> </button>
<button class="button button3">6 month <br> (Rs.720) <a href="Bill1c.php?uid=<?php echo $uid ?>&pid=1"><br> Subscribe </a> </button>
<center>

</body>
</html>
