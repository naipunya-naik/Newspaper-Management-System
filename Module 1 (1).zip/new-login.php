<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/logo.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/images.jfif');">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="POST">
					<span class="login100-form-logo">
						<i class="zmdi zmdi-landscape"></i>
					</span>

					<span class="login100-form-title p-b-34 p-t-27">
						Log in
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<span class="glyphicon glyphicon-user"></span>
						<input class="input100" type="text" name="uname" placeholder="Email" required>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<span class="glyphicon glyphicon-lock"></span>
						<input class="input100" type="password" name="password" placeholder="Password" required>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Enter type(admin/customer)">
						<span class="glyphicon glyphicon-list-alt"></span>
						<input class="input100" type="text" name="type" placeholder="Enter type(admin/customer)" required>		
					</div>


					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit" type="submit" value="abc">
							Login
						</button>
					</div>
					<br>
					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="submit1" type="submit" value="abc" onclick="window.location.href='signup.php'">
							Sign Up
						</button>
					</div>
						
						

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>

<?php 

	if(isset($_POST['submit']))
	{
		$uid=$_POST['uname'];
		$pass=$_POST['password'];
		$type=$_POST['type'];

		$sql="SELECT * FROM login WHERE type='$type' AND uid='$uid' AND pass='$pass'";
		$result=mysqli_query($conn,$sql);
		if(empty($result))
		{
			echo "
				<script>
				
					alert('Login Failed');
				
				</script>
			
			";
		}
		else
		{
			$row=mysqli_fetch_assoc($result);
			if($row['type']=="admin")
			{
			?>
				<script>
					alert('logged in as admin');
					window.location.href="admin-customer details.php?uid=<?php echo $uid; ?>"
				</script>
				<?php
			}
			else if($row['type']=="customer")
			{
			?>
				<script>
					alert('logged in as customer');
					window.location.href ="custom-require.php?uid=<?php echo $uid; ?>"
				</script>";
				<?php
			}
			else 
			{
				echo "
				<script>
				
					alert('Login Failed');
				
				</script>
			
			";
			}
				
		}

	}


?>