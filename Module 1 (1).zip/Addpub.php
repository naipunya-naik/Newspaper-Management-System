<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid;
?>
<html>
<head>
<link rel="stylesheet" href="signupstyle.css"></link>
</head>
<body>
<form  style="border:1px solid #ccc" method="POST">
  <div class="container">
    <h1>Add Publisher</h1>
    <p>Fill publisher details.</p>
    <hr>

	<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>

	<label for="phonenumber"><b>Contact</b></label>
    <input type="text" placeholder="Enter Phone Number" name="phonenumber" required>

	<label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" required>

    <label for="email"><b>Papers/day</b></label>
    <input type="text" placeholder="papers/day" name="pap" required>

    <label for="name"><b>Editor name</b></label>
    <input type="text" placeholder="Enter name" name="edi" required>

  
    </label>

    

    <div class="clearfix">
     
      <button type="submit" class="signupbtn" name="submit" value="abc">Add</button>
    </div>
  </div>
</form>
</body>
</html>

<?php 

	if(isset($_POST['submit']))
	{
		$name=$_POST['name'];
		$phonenumber=$_POST['phonenumber'];
		$address=$_POST['address'];
		$email=$_POST['pap'];
		$psw=$_POST['edi'];

		$sql="INSERT INTO publisher_details(name,phonenumber,address,pd,ediname) VALUES ('$name','$phonenumber','$address','$email','$psw')";
		$result=mysqli_query($conn,$sql);
			if($result)
			{
				echo "<script>alert('INSERTED SUCCESSFULLY');window.location.href='admin-publisher details.php?uid=admin-001'</script>";
			} 
			else
			echo "<script>alert('INSERT UNSUCCESSFULL');</script>";
	}
?>
