<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
<html>
<head>
<link rel="stylesheet" href="signupstyle.css"></link>
</head>
<body>
<form  style="border:1px solid #ccc" method="POST">
  <div class="container">
    <h1>Sign Up</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>

	<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>

	<label for="phonenumber"><b>Phone Number</b></label>
    <input type="text" placeholder="Enter Phone Number" name="phonenumber" required>

	<label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

  
    </label>

    

    <div class="clearfix">
     
      <button type="submit" class="signupbtn" name="submit" value="abc">Sign Up</button>
    </div>
  </div>
</form>
</body>
</html>

<?php 

	if(isset($_POST['submit']))
	{
		$name=$_POST['name'];
		$phonenumber=$_POST['phonenumber'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$psw=$_POST['psw'];

		$sql="INSERT INTO customer_details(name,phonenumber,address,email,psw) VALUES ('$name','$phonenumber','$address','$email','$psw')";
		$result=mysqli_query($conn,$sql);
			if($result)
			{
				$sql2="INSERT INTO login VALUES ('$email','$psw','customer')";
				$result2=mysqli_query($conn,$sql2);
				echo "<script>alert('INSERTED SUCCESSFULLY');window.location.href='new-login.php'</script>";
			} 
			else
			echo "<script>alert('INSERT UNSUCCESSFULL');</script>";
	}
?>
