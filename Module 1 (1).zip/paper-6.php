<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid;
?>
<html>	
<body>
<h1 align="center" <br>Indian Express</h1>
</body>
</html>
</html>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style2.css"></link>
<style>
.button {
  border: none;
  color: white;
  padding: 40px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 40px 60px;
  cursor: pointer;
}

.button1 {background-color: #f44336;} /* Red */
.button2 {background-color: #e7e7e7; color: black;} /* Gray */
.button3 {background-color: #555555;} /* Black */

.button1 {border-radius: 12px;}
.button2 {border-radius: 12px;}
.button3 {border-radius: 12px;}
</style>
</head>
<body>
<img src="images/images.jfif">
<center>
<button class="button button1">1 month <br> (Rs.90)  <a href="Bill6a.php?uid=<?php echo $uid ?>&pid=6"><br> Subscribe </a> </button>
<button class="button button2">3 month <br> (Rs.270)  <a href="Bill6b.php?uid=<?php echo $uid ?>&pid=6"><br> Subscribe </a> </button>
<button class="button button3">6 month <br> (Rs.540)  <a href="Bill6c.php?uid=<?php echo $uid ?>&pid=6"><br> Subscribe </a> </button>
</center>
</body>
</html>
