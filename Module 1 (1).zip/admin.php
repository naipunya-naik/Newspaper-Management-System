<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
<html>
    <head>
		<link rel="stylesheet" href="style.css"></link>
    </head>
    <body>
	
	<div class="topnav">
        <a href="admin-customer details.php">Customer Details</a>
        <a href="admin-requirement details.php">Requirement Details</a>
        <a href="admin-supplier details.php">Supplier Details</a>
		<a href="admin-payment details.php">Payment Details</a>
		<a href="admin-publication details.php">Publication Details</a>
	</div>
    </body>
</html>