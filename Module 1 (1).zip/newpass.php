<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid;

?>
<html>
<head>
<link rel="stylesheet" href="signupstyle.css"></link>
</head>
<body>
<form  style="border:1px solid #ccc" method="POST">
  <div class="container">
    <h1>Change Password</h1>
    <p></p>
    <hr>

	<label for="name"><b>Current Password</b></label>
    <input type="text" placeholder="Enter Current Password" name="pass" required>

	<label for="phonenumber"><b>New Password</b></label>
    <input type="text" placeholder="Enter New Password" name="npass" required>
    </label>

    

    <div class="clearfix">
     
      <button type="submit" class="signupbtn" name="submit" value="abc">Change Password</button>
    </div>
  </div>
</form>
</body>
</html>

<?php 

	if(isset($_POST['submit']))
	{
		$pass=$_POST['pass'];
		$npass=$_POST['npass'];

		$sql="SELECT pass FROM login WHERE uid='$uid'";
		$result=mysqli_query($conn,$sql);
		$row=mysqli_fetch_array($result);
		if(empty($result))
		{
			echo "
				<script>
				
					alert('Please Enter Password');
				
				</script>
			
			";
		}
		
		if($row['pass']==$pass)
		{
			$sql2="call updpass('$npass','$uid')"; //stored procedure
			$res=mysqli_query($conn,$sql2);
			echo "
				<script>
				
					alert('Password Changed Successfully');
				
				</script>
			
			";
		}
		else 
		{
			
			echo "
				<script>
				
					alert('Please Enter Correct Password');
				
				</script>
			
			";
		}
	}
?>
