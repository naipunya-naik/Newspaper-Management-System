<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'nms';
$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$uid = $_GET['uid'];
echo $uid;

$sql="SELECT e.email,s.pid,r.papername FROM customer_details e,subs s,requirements r where r.pid=s.pid and e.email=s.email";
$res=mysqli_query($conn,$sql);
?>
<html>
    <head>
		<link rel="stylesheet" href="style.css"></link>
    </head>
    <body>
	
	<div class="topnav">
        <a href="admin-customer details.php?uid=<?php echo $uid?>">Customer Details</a>
		<a href="admin-signuplogs.php?uid=<?php echo $uid?>">Subscription Logs</a>
        <a href="admin-requirement details.php?uid=<?php echo $uid?>">Subscriber Details</a>
		<a href="admin-publisher details.php?uid=<?php echo $uid?>">Publication Details</a>
		<a href="newpass.php?uid=<?php echo $uid?>">Change password</a>
		<a href="new-login.php">Logout</a>
	</div>
	<!DOCTYPE html>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

<table>
  <tr>
    <th>Email</th>
    <th>Pid</th>
    <th>Papername</th>
  </tr>
  <?php   
  while($row=mysqli_fetch_array($res))
  {
  ?>
		  <tr>
			<td><?php echo $row['email'] ?></td>
			<td><?php echo $row['pid'] ?></td>
			<td><?php echo $row['papername'] ?></td>
		  </tr>
  <?php 
  }
  ?>
</table>

</body>
</html>